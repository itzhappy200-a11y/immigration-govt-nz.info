export const STANDALONE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Netflix - Watch TV Shows Online, Watch Movies Online</title>
  <!-- Tailwind CSS CDN for instant styling -->
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
    
    body {
      margin: 0;
      background-color: #141414;
      color: #ffffff;
      font-family: 'Inter', "Helvetica Neue", Helvetica, Arial, sans-serif;
      overflow-x: hidden;
    }
    
    /* Hide scrollbars for sliders */
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    
    /* Custom thin scrollbar for modal */
    .nfx-scroll::-webkit-scrollbar { width: 8px; }
    .nfx-scroll::-webkit-scrollbar-track { background: #181818; }
    .nfx-scroll::-webkit-scrollbar-thumb { background: #4d4d4d; border-radius: 4px; }
    
    /* Netflix Top 10 large outline numbers */
    .top10-number {
      -webkit-text-stroke: 3.5px #595959;
      color: #141414;
      font-weight: 900;
      letter-spacing: -0.05em;
      line-height: 0.75;
      user-select: none;
    }
    
    .text-shadow-md {
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.6);
    }
    
    /* Smooth transitions */
    .row-card { transition: transform 0.28s cubic-bezier(0.2, 0.7, 0.3, 1), z-index 0.2s; }
    .row-card:hover { transform: scale(1.35); z-index: 30; }
  </style>
</head>
<body class="bg-[#141414] min-h-screen text-white">

  <!-- TOP NAVIGATION BAR -->
  <header id="navbar" class="fixed top-0 left-0 right-0 z-50 transition-colors duration-400 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
    <div class="flex items-center h-[68px] px-[4%] text-[14px]">
      <!-- Netflix Logo -->
      <a href="#" class="mr-6 shrink-0">
        <svg class="w-24 h-7 fill-[#e50914]" viewBox="0 0 1024 276.74">
          <path d="M140.803 258.904c-15.404 2.705-31.079 3.516-47.294 5.676l-49.458-144.856v151.073c-15.404 1.621-29.457 3.783-44.051 5.945v-276.742h41.08l56.212 157.021v-157.021h43.511v258.904zm85.131-157.558c16.757 0 42.431-.811 57.835-.811v43.24c-19.189 0-41.619 0-57.835.811v64.322c25.405-1.621 50.809-3.785 76.482-4.596v41.617l-119.724 9.461v-255.39h119.724v43.241h-76.482v58.105zm237.284-58.104h-44.862v198.908c-14.594 0-29.188 0-43.239.539v-199.447h-44.862v-43.242h132.965l-.002 43.242zm70.266 55.132h59.187v43.24h-59.187v98.104h-42.433v-239.718h120.808v43.241h-78.375v55.133zm148.641 103.507c24.594.539 49.456 2.434 73.51 3.783v42.701c-38.646-2.434-77.293-4.863-116.75-5.676v-242.689h43.24v201.881zm109.994 49.457c13.783.812 28.377 1.623 42.43 3.242v-254.58h-42.43v251.338zm231.881-251.338l-54.863 131.615 54.863 145.127c-16.217-2.162-32.432-5.135-48.648-7.838l-31.078-79.994-31.617 73.51c-15.678-2.705-30.812-3.516-46.484-5.678l55.672-126.75-50.269-129.992h46.482l28.377 72.699 30.27-72.699h47.295z" />
        </svg>
      </a>

      <!-- Desktop Nav -->
      <nav class="hidden lg:flex items-center gap-5 font-medium text-sm text-[#e5e5e5]">
        <a href="#" class="text-white font-semibold">Home</a>
        <a href="#" class="hover:text-[#b3b3b3] transition">TV Shows</a>
        <a href="#" class="hover:text-[#b3b3b3] transition">Movies</a>
        <a href="#" class="hover:text-[#b3b3b3] transition">New & Popular</a>
        <a href="#" id="nav-mylist" class="hover:text-[#b3b3b3] transition">My List <span id="list-count" class="hidden ml-1 px-1.5 py-0.5 text-[10px] bg-[#e50914] rounded-full text-white">0</span></a>
        <a href="#" class="hover:text-[#b3b3b3] transition">Browse by Languages</a>
      </nav>

      <!-- Right Actions -->
      <div class="ml-auto flex items-center gap-5">
        <!-- Search Button / Input -->
        <div class="relative flex items-center">
          <input id="search-input" type="text" placeholder="Titles, genres..." class="hidden w-48 bg-black/80 border border-white/60 px-3 py-1 text-xs text-white outline-none rounded pr-8 transition">
          <button id="search-toggle" aria-label="Search" class="p-1 hover:scale-110 transition">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35" stroke-linecap="round"/></svg>
          </button>
        </div>

        <span class="hidden md:block text-sm cursor-pointer hover:text-[#b3b3b3]">Kids</span>

        <!-- Notifications Bell -->
        <div class="relative">
          <button id="bell-btn" class="relative block p-1" aria-label="Notifications">
            <svg class="w-5 h-5 text-white fill-current" viewBox="0 0 24 24"><path d="M12 2a6.5 6.5 0 0 0-6.5 6.5v3.2L3.3 16.2a.8.8 0 0 0 .7 1.2h16a.8.8 0 0 0 .7-1.2l-2.2-4.5V8.5A6.5 6.5 0 0 0 12 2Z"/><path d="M9.6 18.6a2.5 2.5 0 0 0 4.8 0z"/></svg>
            <span class="absolute top-0 right-0 w-3.5 h-3.5 bg-[#e50914] rounded-full text-[9px] font-bold flex items-center justify-center">2</span>
          </button>
          <!-- Notification Popup -->
          <div id="bell-popup" class="hidden absolute right-0 top-10 w-80 bg-black/90 border-t-2 border-white p-2 text-xs shadow-2xl">
            <div class="p-2 border-b border-white/10 flex gap-3 items-center hover:bg-white/10 cursor-pointer" onclick="openModal('NIGHTFALL')">
              <img src="https://images.pexels.com/photos/30179307/pexels-photo-30179307.jpeg?auto=compress&w=150" class="w-16 h-10 object-cover rounded">
              <div>
                <p class="font-bold text-white">New Season Now Available</p>
                <p class="text-gray-400">Nightfall - 72 Hours of Darkness</p>
                <p class="text-[10px] text-gray-500 mt-0.5">1h ago</p>
              </div>
            </div>
            <div class="p-2 flex gap-3 items-center hover:bg-white/10 cursor-pointer" onclick="openModal('ORBITAL')">
              <img src="https://images.pexels.com/photos/7672873/pexels-photo-7672873.jpeg?auto=compress&w=150" class="w-16 h-10 object-cover rounded">
              <div>
                <p class="font-bold text-white">New Sci-Fi Thriller</p>
                <p class="text-gray-400">Orbital is trending #1</p>
                <p class="text-[10px] text-gray-500 mt-0.5">1d ago</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Profile Avatar -->
        <div class="relative group cursor-pointer flex items-center gap-2">
          <div class="w-8 h-8 rounded bg-gradient-to-tr from-[#e50914] to-[#8b0000] flex items-center justify-center font-bold text-sm shadow">A</div>
          <svg class="w-3 h-3 text-white transition transform group-hover:rotate-180 hidden sm:block" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>
          
          <!-- Dropdown -->
          <div class="hidden group-hover:block absolute right-0 top-8 pt-2 w-48 z-50">
            <div class="bg-black/95 border-t-2 border-white py-2 text-xs text-[#e5e5e5]">
              <div class="px-4 py-2 hover:underline flex items-center gap-3"><div class="w-6 h-6 rounded bg-blue-600 flex items-center justify-center font-bold text-[10px]">K</div> Kids Profile</div>
              <div class="px-4 py-2 hover:underline flex items-center gap-3"><div class="w-6 h-6 rounded bg-emerald-600 flex items-center justify-center font-bold text-[10px]">S</div> Sam</div>
              <hr class="border-white/20 my-1">
              <div class="px-4 py-2 hover:underline">Manage Profiles</div>
              <div class="px-4 py-2 hover:underline">Account & Settings</div>
              <hr class="border-white/20 my-1">
              <div class="px-4 py-2 text-center hover:underline text-white font-medium" onclick="alert('Signed out!')">Sign out of Netflix</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- HERO BILLBOARD -->
  <section class="relative w-full h-[75vh] min-h-[520px] max-h-[850px] flex items-center overflow-hidden">
    <!-- Hero Image Background -->
    <img id="hero-bg" src="https://images.pexels.com/photos/30179307/pexels-photo-30179307.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1080" 
         alt="Hero Billboard" 
         class="absolute inset-0 w-full h-full object-cover object-[65%_center] filter brightness-90">
    
    <!-- Netflix Vignettes & Gradients -->
    <div class="absolute inset-0 bg-gradient-to-r from-black/95 via-black/50 to-transparent"></div>
    <div class="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/30 to-transparent"></div>
    
    <!-- Hero Content -->
    <div class="relative z-10 px-[4%] max-w-[660px] mt-12">
      <div class="flex items-center gap-2 mb-3">
        <span class="text-[#e50914] font-black text-2xl tracking-tighter">N</span>
        <span class="text-[13px] font-bold tracking-[0.25em] text-gray-300 uppercase">Original Series</span>
      </div>

      <h1 class="text-shadow-md text-5xl sm:text-7xl font-black uppercase tracking-tight text-white mb-4">
        NIGHTFALL
      </h1>

      <div class="flex flex-wrap items-center gap-3 text-sm font-semibold mb-4">
        <span class="bg-[#e50914] text-white text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">New Season</span>
        <span class="text-[#46d369]">99% Match</span>
        <span class="text-gray-300">2026</span>
        <span class="border border-white/40 px-1.5 text-xs text-gray-300">TV-MA</span>
        <span class="text-gray-300">3 Seasons</span>
        <span class="border border-white/40 px-1 text-[10px] text-gray-400 rounded">4K Ultra HD</span>
      </div>

      <p class="text-shadow-md text-gray-200 text-sm sm:text-lg leading-relaxed mb-6">
        When the lights go out across the massive grid for seventy-two hours, a disgraced detective and a mysterious underground broker must unite to stop an irreversible countdown before dawn.
      </p>

      <div class="flex items-center gap-4">
        <button onclick="playTitle('NIGHTFALL')" class="flex items-center gap-2 bg-white text-black hover:bg-white/80 transition font-bold px-7 py-2.5 rounded text-lg sm:text-xl shadow">
          <svg class="w-6 h-6 fill-current" viewBox="0 0 24 24"><path d="M5 3.868v16.264a1 1 0 0 0 1.53.848l12.79-8.132a1 1 0 0 0 0-1.696L6.53 3.02A1 1 0 0 0 5 3.868Z"/></svg>
          Play
        </button>
        <button onclick="openModal('NIGHTFALL')" class="flex items-center gap-2 bg-[#535353]/70 hover:bg-[#535353]/90 text-white font-bold px-7 py-2.5 rounded text-lg sm:text-xl backdrop-blur-sm transition">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 11v5M12 8h.01"/></svg>
          More Info
        </button>
      </div>
    </div>

    <!-- Right Side Mute & Maturity tag -->
    <div class="absolute right-0 bottom-24 hidden md:flex items-center gap-4 z-10">
      <button id="mute-btn" class="w-10 h-10 rounded-full border-2 border-white/60 hover:border-white bg-black/40 flex items-center justify-center text-white transition" title="Mute/Unmute audio preview">
        <svg id="mute-icon" class="w-5 h-5 stroke-current" fill="none" stroke-width="2" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path id="mute-cross" d="m23 9-6 6M17 9l6 6"/></svg>
      </button>
      <div class="bg-black/60 border-l-[3px] border-white pl-3 pr-6 py-1 text-sm font-semibold backdrop-blur-sm text-gray-200">
        TV-MA <span class="text-xs text-gray-400 ml-2">Violence, Language</span>
      </div>
    </div>
  </section>

  <!-- MAIN CONTENT ROWS -->
  <main class="relative z-20 -mt-20 pb-16 space-y-10 px-[4%]">
    
    <!-- ROW 1: Trending Now (Standard Carousel) -->
    <div class="row-container">
      <h2 class="text-xl sm:text-2xl font-bold text-[#e5e5e5] hover:text-white mb-3 flex items-center gap-1 cursor-pointer">
        Trending Now <span class="text-[#54b9c5] text-sm hidden sm:inline-block ml-2 opacity-0 group-hover:opacity-100 transition">Explore All &rsaquo;</span>
      </h2>
      <div class="relative group">
        <button class="scroll-left hidden sm:flex absolute left-0 top-0 bottom-0 w-12 z-40 bg-black/50 hover:bg-black/80 items-center justify-center text-white opacity-0 group-hover:opacity-100 transition -ml-4"><svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="m15 19-7-7 7-7"/></svg></button>
        
        <div class="row-scroll flex gap-3 overflow-x-auto no-scrollbar py-2 scroll-smooth">
          <!-- Dynamically generated or statically detailed cards -->
          <div onclick="openModal('ORBITAL')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800 shadow-md">
            <img src="https://images.pexels.com/photos/7672873/pexels-photo-7672873.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <span class="absolute top-2 left-2 bg-[#e50914] text-[10px] font-bold px-1.5 py-0.5 rounded shadow uppercase">New</span>
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition flex flex-col justify-end p-3">
              <p class="font-bold text-sm">Orbital</p>
              <p class="text-xs text-[#46d369] font-semibold">98% Match &bull; 2026</p>
            </div>
          </div>
          <div onclick="openModal('THE SILENT HOUR')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800 shadow-md">
            <img src="https://images.pexels.com/photos/23384428/pexels-photo-23384428.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition flex flex-col justify-end p-3">
              <p class="font-bold text-sm">The Silent Hour</p>
              <p class="text-xs text-[#46d369] font-semibold">95% Match &bull; Action</p>
            </div>
          </div>
          <div onclick="openModal('HOLLOW PINES')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800 shadow-md">
            <img src="https://images.pexels.com/photos/15292814/pexels-photo-15292814.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition flex flex-col justify-end p-3">
              <p class="font-bold text-sm">Hollow Pines</p>
              <p class="text-xs text-[#46d369] font-semibold">91% Match &bull; Horror</p>
            </div>
          </div>
          <div onclick="openModal('DUST & DIESEL')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800 shadow-md">
            <img src="https://images.pexels.com/photos/30180763/pexels-photo-30180763.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <span class="absolute top-2 left-2 bg-zinc-900/90 text-red-500 border border-red-500/30 text-[9px] font-bold px-1.5 py-0.5 rounded shadow">Top 10</span>
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition flex flex-col justify-end p-3">
              <p class="font-bold text-sm">Dust & Diesel</p>
              <p class="text-xs text-[#46d369] font-semibold">97% Match &bull; Action</p>
            </div>
          </div>
          <div onclick="openModal('CYBER MATRIX')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800 shadow-md">
            <img src="https://images.pexels.com/photos/8108316/pexels-photo-8108316.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition flex flex-col justify-end p-3">
              <p class="font-bold text-sm">Cyber Matrix</p>
              <p class="text-xs text-[#46d369] font-semibold">89% Match &bull; Sci-Fi</p>
            </div>
          </div>
          <div onclick="openModal('VINTAGE HEARTS')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800 shadow-md">
            <img src="https://images.pexels.com/photos/21336125/pexels-photo-21336125.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition flex flex-col justify-end p-3">
              <p class="font-bold text-sm">Vintage Hearts</p>
              <p class="text-xs text-[#46d369] font-semibold">94% Match &bull; Drama</p>
            </div>
          </div>
        </div>
        
        <button class="scroll-right hidden sm:flex absolute right-0 top-0 bottom-0 w-12 z-40 bg-black/50 hover:bg-black/80 items-center justify-center text-white opacity-0 group-hover:opacity-100 transition -mr-4"><svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></svg></button>
      </div>
    </div>

    <!-- ROW 2: Top 10 Today in the U.S. (Large Numerals) -->
    <div class="row-container pt-4">
      <h2 class="text-xl sm:text-2xl font-bold text-[#e5e5e5] mb-3">Top 10 TV Shows in the U.S. Today</h2>
      <div class="row-scroll flex gap-6 overflow-x-auto no-scrollbar py-3">
        <div onclick="openModal('NIGHTFALL')" class="flex-none flex items-end cursor-pointer group w-[210px] sm:w-[250px] relative">
          <span class="top10-number text-7xl sm:text-8xl pl-2 w-[45%] z-10 group-hover:text-white transition">1</span>
          <img src="https://images.pexels.com/photos/30179307/pexels-photo-30179307.jpeg?auto=compress&w=400" class="w-[55%] aspect-[2/3] object-cover rounded shadow-lg transition duration-300 transform group-hover:scale-105 group-hover:-translate-y-2">
        </div>
        <div onclick="openModal('ORBITAL')" class="flex-none flex items-end cursor-pointer group w-[210px] sm:w-[250px] relative">
          <span class="top10-number text-7xl sm:text-8xl pl-2 w-[45%] z-10 group-hover:text-white transition">2</span>
          <img src="https://images.pexels.com/photos/7672873/pexels-photo-7672873.jpeg?auto=compress&w=400" class="w-[55%] aspect-[2/3] object-cover rounded shadow-lg transition duration-300 transform group-hover:scale-105 group-hover:-translate-y-2">
        </div>
        <div onclick="openModal('DUST & DIESEL')" class="flex-none flex items-end cursor-pointer group w-[210px] sm:w-[250px] relative">
          <span class="top10-number text-7xl sm:text-8xl pl-2 w-[45%] z-10 group-hover:text-white transition">3</span>
          <img src="https://images.pexels.com/photos/30180763/pexels-photo-30180763.jpeg?auto=compress&w=400" class="w-[55%] aspect-[2/3] object-cover rounded shadow-lg transition duration-300 transform group-hover:scale-105 group-hover:-translate-y-2">
        </div>
        <div onclick="openModal('HOLLOW PINES')" class="flex-none flex items-end cursor-pointer group w-[210px] sm:w-[250px] relative">
          <span class="top10-number text-7xl sm:text-8xl pl-2 w-[45%] z-10 group-hover:text-white transition">4</span>
          <img src="https://images.pexels.com/photos/15292814/pexels-photo-15292814.jpeg?auto=compress&w=400" class="w-[55%] aspect-[2/3] object-cover rounded shadow-lg transition duration-300 transform group-hover:scale-105 group-hover:-translate-y-2">
        </div>
        <div onclick="openModal('THE SILENT HOUR')" class="flex-none flex items-end cursor-pointer group w-[210px] sm:w-[250px] relative">
          <span class="top10-number text-7xl sm:text-8xl pl-2 w-[45%] z-10 group-hover:text-white transition">5</span>
          <img src="https://images.pexels.com/photos/23384428/pexels-photo-23384428.jpeg?auto=compress&w=400" class="w-[55%] aspect-[2/3] object-cover rounded shadow-lg transition duration-300 transform group-hover:scale-105 group-hover:-translate-y-2">
        </div>
      </div>
    </div>

    <!-- ROW 3: Continue Watching for Alex (With Progress Bars) -->
    <div class="row-container pt-4">
      <h2 class="text-xl sm:text-2xl font-bold text-[#e5e5e5] mb-3">Continue Watching for Alex</h2>
      <div class="row-scroll flex gap-3 overflow-x-auto no-scrollbar py-2">
        <div onclick="openModal('THE SILENT HOUR')" class="row-card flex-none w-[200px] sm:w-[260px] bg-[#181818] rounded overflow-hidden cursor-pointer group">
          <div class="relative aspect-video">
            <img src="https://images.pexels.com/photos/23384400/pexels-photo-23384400.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
              <div class="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center bg-black/60"><svg class="w-5 h-5 fill-white ml-0.5" viewBox="0 0 24 24"><path d="M5 3.868v16.264a1 1 0 0 0 1.53.848l12.79-8.132a1 1 0 0 0 0-1.696L6.53 3.02A1 1 0 0 0 5 3.868Z"/></svg></div>
            </div>
            <span class="absolute bottom-1.5 left-2 text-[11px] font-medium text-white/90 bg-black/60 px-1 rounded">S2:E4 "The Setup"</span>
          </div>
          <div class="h-[4px] bg-zinc-700 w-full"><div class="h-full bg-[#e50914] w-[70%]"></div></div>
        </div>
        <div onclick="openModal('CYBER MATRIX')" class="row-card flex-none w-[200px] sm:w-[260px] bg-[#181818] rounded overflow-hidden cursor-pointer group">
          <div class="relative aspect-video">
            <img src="https://images.pexels.com/photos/14044350/pexels-photo-14044350.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
              <div class="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center bg-black/60"><svg class="w-5 h-5 fill-white ml-0.5" viewBox="0 0 24 24"><path d="M5 3.868v16.264a1 1 0 0 0 1.53.848l12.79-8.132a1 1 0 0 0 0-1.696L6.53 3.02A1 1 0 0 0 5 3.868Z"/></svg></div>
            </div>
            <span class="absolute bottom-1.5 left-2 text-[11px] font-medium text-white/90 bg-black/60 px-1 rounded">S1:E8 "Overclock"</span>
          </div>
          <div class="h-[4px] bg-zinc-700 w-full"><div class="h-full bg-[#e50914] w-[35%]"></div></div>
        </div>
        <div onclick="openModal('HOLLOW PINES')" class="row-card flex-none w-[200px] sm:w-[260px] bg-[#181818] rounded overflow-hidden cursor-pointer group">
          <div class="relative aspect-video">
            <img src="https://images.pexels.com/photos/18634896/pexels-photo-18634896.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
            <span class="absolute bottom-1.5 left-2 text-[11px] font-medium text-white/90 bg-black/60 px-1 rounded">20m remaining</span>
          </div>
          <div class="h-[4px] bg-zinc-700 w-full"><div class="h-full bg-[#e50914] w-[85%]"></div></div>
        </div>
      </div>
    </div>

    <!-- ROW 4: Action & Sci-Fi Thrillers -->
    <div class="row-container pt-4">
      <h2 class="text-xl sm:text-2xl font-bold text-[#e5e5e5] mb-3">Action & Sci-Fi Thrillers</h2>
      <div class="row-scroll flex gap-3 overflow-x-auto no-scrollbar py-2">
        <div onclick="openModal('ORBITAL')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800">
          <img src="https://images.pexels.com/photos/7661481/pexels-photo-7661481.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
          <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition p-3 flex flex-col justify-end"><p class="font-bold text-sm">Deep Space 9</p></div>
        </div>
        <div onclick="openModal('DUST & DIESEL')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800">
          <img src="https://images.pexels.com/photos/30925253/pexels-photo-30925253.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
          <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition p-3 flex flex-col justify-end"><p class="font-bold text-sm">Rally Drift</p></div>
        </div>
        <div onclick="openModal('NIGHTFALL')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800">
          <img src="https://images.pexels.com/photos/32891033/pexels-photo-32891033.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
          <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition p-3 flex flex-col justify-end"><p class="font-bold text-sm">Underground Agent</p></div>
        </div>
        <div onclick="openModal('CYBER MATRIX')" class="row-card flex-none w-[200px] sm:w-[260px] aspect-video rounded overflow-hidden cursor-pointer relative bg-zinc-800">
          <img src="https://images.pexels.com/photos/29326301/pexels-photo-29326301.jpeg?auto=compress&w=500" class="w-full h-full object-cover">
          <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 hover:opacity-100 transition p-3 flex flex-col justify-end"><p class="font-bold text-sm">Tokyo Cyber</p></div>
        </div>
      </div>
    </div>
  </main>

  <!-- DETAIL / MORE INFO MODAL -->
  <div id="modal-overlay" class="hidden fixed inset-0 z-50 bg-black/75 backdrop-blur-xs overflow-y-auto nfx-scroll flex justify-center py-10 px-3">
    <div id="modal-box" class="bg-[#181818] rounded-md overflow-hidden max-w-[850px] w-full text-white shadow-2xl relative self-start my-auto border border-white/10" onclick="event.stopPropagation()">
      <!-- Close Button -->
      <button onclick="closeModal()" aria-label="Close modal" class="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-[#181818] hover:bg-[#2a2a2a] flex items-center justify-center text-white font-bold transition">&times;</button>
      
      <!-- Modal Billboard Art -->
      <div class="relative aspect-video w-full">
        <img id="modal-img" src="https://images.pexels.com/photos/30179307/pexels-photo-30179307.jpeg?auto=compress&w=1200" class="w-full h-full object-cover">
        <div class="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-transparent"></div>
        <div class="absolute bottom-6 left-6 right-6 flex items-end justify-between">
          <div>
            <h2 id="modal-title" class="text-3xl sm:text-5xl font-black uppercase text-white mb-3">NIGHTFALL</h2>
            <div class="flex items-center gap-3">
              <button onclick="playTitle(document.getElementById('modal-title').innerText)" class="bg-white text-black font-bold px-6 py-2 rounded flex items-center gap-2 hover:bg-white/85 transition text-base">
                <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M5 3.868v16.264a1 1 0 0 0 1.53.848l12.79-8.132a1 1 0 0 0 0-1.696L6.53 3.02A1 1 0 0 0 5 3.868Z"/></svg>
                Play
              </button>
              <button id="modal-add-btn" onclick="toggleMyList(document.getElementById('modal-title').innerText)" class="w-10 h-10 rounded-full border-2 border-white/70 hover:border-white bg-[#2a2a2a] flex items-center justify-center text-xl" title="Add to My List">+</button>
              <button onclick="alert('Liked this title!')" class="w-10 h-10 rounded-full border-2 border-white/70 hover:border-white bg-[#2a2a2a] flex items-center justify-center text-sm" title="I like this">👍</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Body Specs -->
      <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-3">
          <div class="flex items-center gap-3 text-sm font-semibold">
            <span class="text-[#46d369]">99% Match</span>
            <span class="text-gray-400">2026</span>
            <span class="border border-white/40 px-1 text-xs text-gray-300">TV-MA</span>
            <span class="text-gray-300">3 Seasons</span>
            <span class="border border-white/40 px-1 text-[10px] text-gray-400">HD</span>
          </div>
          <p id="modal-desc" class="text-sm text-gray-200 leading-relaxed">
            When the lights go out across the massive grid for seventy-two hours, a disgraced detective and a mysterious underground broker must unite to stop an irreversible countdown before dawn.
          </p>
        </div>
        <div class="text-xs space-y-2 text-gray-400 border-t md:border-t-0 pt-4 md:pt-0 border-white/10">
          <p><span class="text-gray-500">Cast:</span> Mara Ellison, Tobias Kane, Priya Raghunathan</p>
          <p><span class="text-gray-500">Genres:</span> Thriller, Crime TV, Mystery</p>
          <p><span class="text-gray-500">This show is:</span> Suspenseful, Dark, Gritty</p>
        </div>
      </div>

      <!-- More Like This preview section -->
      <div class="px-6 pb-8">
        <h3 class="font-bold text-lg mb-3 text-white">More Like This</h3>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div class="bg-[#2f2f2f] rounded overflow-hidden p-2 text-xs flex flex-col justify-between">
            <img src="https://images.pexels.com/photos/8271461/pexels-photo-8271461.jpeg?auto=compress&w=300" class="w-full aspect-video object-cover rounded mb-2">
            <p class="font-semibold text-white">Neon Requiem</p>
            <p class="text-[11px] text-[#46d369]">96% Match</p>
          </div>
          <div class="bg-[#2f2f2f] rounded overflow-hidden p-2 text-xs flex flex-col justify-between">
            <img src="https://images.pexels.com/photos/31420645/pexels-photo-31420645.jpeg?auto=compress&w=300" class="w-full aspect-video object-cover rounded mb-2">
            <p class="font-semibold text-white">The Amber Room</p>
            <p class="text-[11px] text-[#46d369]">92% Match</p>
          </div>
          <div class="bg-[#2f2f2f] rounded overflow-hidden p-2 text-xs flex flex-col justify-between">
            <img src="https://images.pexels.com/photos/7991501/pexels-photo-7991501.jpeg?auto=compress&w=300" class="w-full aspect-video object-cover rounded mb-2">
            <p class="font-semibold text-white">Cold Harbour</p>
            <p class="text-[11px] text-[#46d369]">89% Match</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- FOOTER -->
  <footer class="max-w-5xl mx-auto px-[4%] py-12 text-sm text-[#737373] space-y-6 border-t border-white/10">
    <div class="flex gap-6 text-white">
      <span class="cursor-pointer hover:underline">Facebook</span>
      <span class="cursor-pointer hover:underline">Instagram</span>
      <span class="cursor-pointer hover:underline">Twitter / X</span>
      <span class="cursor-pointer hover:underline">YouTube</span>
    </div>
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
      <a href="#" class="hover:underline">Audio Description</a>
      <a href="#" class="hover:underline">Help Centre</a>
      <a href="#" class="hover:underline">Gift Cards</a>
      <a href="#" class="hover:underline">Media Centre</a>
      <a href="#" class="hover:underline">Investor Relations</a>
      <a href="#" class="hover:underline">Jobs</a>
      <a href="#" class="hover:underline">Terms of Use</a>
      <a href="#" class="hover:underline">Privacy</a>
      <a href="#" class="hover:underline">Legal Notices</a>
      <a href="#" class="hover:underline">Cookie Preferences</a>
      <a href="#" class="hover:underline">Corporate Information</a>
      <a href="#" class="hover:underline">Contact Us</a>
    </div>
    <button class="border border-[#737373] px-3 py-1.5 text-xs text-[#808080] hover:text-white transition">
      Service Code
    </button>
    <p class="text-xs">&copy; 1997-2026 Netflix, Inc. Built in Pure HTML &amp; Vanilla JavaScript.</p>
  </footer>

  <!-- VANILLA JAVASCRIPT LOGIC -->
  <script>
    // Navbar scroll background change
    window.addEventListener('scroll', () => {
      const nav = document.getElementById('navbar');
      if (window.scrollY > 20) {
        nav.classList.add('bg-[#141414]');
        nav.classList.remove('bg-gradient-to-b');
      } else {
        nav.classList.remove('bg-[#141414]');
        nav.classList.add('bg-gradient-to-b');
      }
    });

    // Mute button toggle
    let isMuted = true;
    const muteBtn = document.getElementById('mute-btn');
    const muteCross = document.getElementById('mute-cross');
    if(muteBtn) {
      muteBtn.addEventListener('click', () => {
        isMuted = !isMuted;
        if (isMuted) {
          muteCross.style.display = 'block';
          muteBtn.setAttribute('title', 'Mute/Unmute audio preview');
        } else {
          muteCross.style.display = 'none';
          muteBtn.setAttribute('title', 'Muted');
        }
      });
    }

    // Notification bell toggle
    const bellBtn = document.getElementById('bell-btn');
    const bellPopup = document.getElementById('bell-popup');
    if (bellBtn && bellPopup) {
      bellBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        bellPopup.classList.toggle('hidden');
      });
      document.addEventListener('click', () => bellPopup.classList.add('hidden'));
    }

    // Search bar interaction
    const searchToggle = document.getElementById('search-toggle');
    const searchInput = document.getElementById('search-input');
    if(searchToggle && searchInput) {
      searchToggle.addEventListener('click', () => {
        searchInput.classList.toggle('hidden');
        if (!searchInput.classList.contains('hidden')) {
          searchInput.focus();
        }
      });
      searchInput.addEventListener('input', (e) => {
        const val = e.target.value.toLowerCase();
        const cards = document.querySelectorAll('.row-card');
        cards.forEach(c => {
          if(!val || c.innerText.toLowerCase().includes(val)) {
            c.style.display = '';
          } else {
            c.style.display = 'none';
          }
        });
      });
    }

    // Carousel right/left scrolling
    document.querySelectorAll('.row-container').forEach(container => {
      const scrollEl = container.querySelector('.row-scroll');
      const btnLeft = container.querySelector('.scroll-left');
      const btnRight = container.querySelector('.scroll-right');

      if(scrollEl && btnRight) {
        btnRight.addEventListener('click', () => {
          scrollEl.scrollBy({ left: scrollEl.clientWidth * 0.8, behavior: 'smooth' });
        });
      }
      if(scrollEl && btnLeft) {
        btnLeft.addEventListener('click', () => {
          scrollEl.scrollBy({ left: -scrollEl.clientWidth * 0.8, behavior: 'smooth' });
        });
      }
    });

    // My List storage in memory
    const myList = new Set();
    function toggleMyList(title) {
      const btn = document.getElementById('modal-add-btn');
      const countEl = document.getElementById('list-count');
      if (myList.has(title)) {
        myList.delete(title);
        if(btn) btn.innerHTML = '+';
      } else {
        myList.add(title);
        if(btn) btn.innerHTML = '&check;';
      }
      if(countEl) {
        if(myList.size > 0) {
          countEl.textContent = myList.size;
          countEl.classList.remove('hidden');
        } else {
          countEl.classList.add('hidden');
        }
      }
    }

    // Modal behavior
    const titlesData = {
      'NIGHTFALL': {
        img: 'https://images.pexels.com/photos/30179307/pexels-photo-30179307.jpeg?auto=compress&w=1200',
        desc: 'When the lights go out across the massive grid for seventy-two hours, a disgraced detective and a mysterious underground broker must unite to stop an irreversible countdown before dawn.'
      },
      'ORBITAL': {
        img: 'https://images.pexels.com/photos/7672873/pexels-photo-7672873.jpeg?auto=compress&w=1200',
        desc: 'A futuristic astronaut awakens inside a deep space research vessel with nine hours of auxiliary oxygen and a scrambled video transmission from her future self.'
      },
      'THE SILENT HOUR': {
        img: 'https://images.pexels.com/photos/23384428/pexels-photo-23384428.jpeg?auto=compress&w=1200',
        desc: 'A SWAT negotiator facing deafening silence during a high-stakes standoff discovers that the hostage takers inside are actually protecting the real target.'
      },
      'HOLLOW PINES': {
        img: 'https://images.pexels.com/photos/15292814/pexels-photo-15292814.jpeg?auto=compress&w=1200',
        desc: 'Every hundred years the foggy forest surrounding this remote mountain town demands a tribute. This year, it chose the sheriff\\'s family.'
      },
      'DUST & DIESEL': {
        img: 'https://images.pexels.com/photos/30180763/pexels-photo-30180763.jpeg?auto=compress&w=1200',
        desc: 'High speed desert racing meets international espionage when an off-road racing crew uncovers a black-market convoy in the Baja wilderness.'
      },
      'CYBER MATRIX': {
        img: 'https://images.pexels.com/photos/8108316/pexels-photo-8108316.jpeg?auto=compress&w=1200',
        desc: 'In a rain-slicked cyberpunk metropolis, a memory broker accidentally acquires a neural recording that rewrites the history of the entire city.'
      },
      'VINTAGE HEARTS': {
        img: 'https://images.pexels.com/photos/21336125/pexels-photo-21336125.jpeg?auto=compress&w=1200',
        desc: 'A gripping historical romance set against the glitz of old Hollywood and the dangerous shadows of post-war Europe.'
      }
    };

    function openModal(title) {
      const overlay = document.getElementById('modal-overlay');
      const titleEl = document.getElementById('modal-title');
      const imgEl = document.getElementById('modal-img');
      const descEl = document.getElementById('modal-desc');
      const addBtn = document.getElementById('modal-add-btn');
      
      const data = titlesData[title] || titlesData['NIGHTFALL'];
      titleEl.innerText = title;
      imgEl.src = data.img;
      descEl.innerText = data.desc;
      
      if(addBtn) {
        addBtn.innerHTML = myList.has(title) ? '&check;' : '+';
      }
      
      overlay.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    }

    function closeModal() {
      document.getElementById('modal-overlay').classList.add('hidden');
      document.body.style.overflow = '';
    }

    function playTitle(title) {
      alert("▶️ Starting playback for: " + title);
    }

    // Close modal on escape or background click
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });
    const overlay = document.getElementById('modal-overlay');
    if(overlay) {
      overlay.addEventListener('click', (e) => {
        if(e.target === overlay) closeModal();
      });
    }
  </script>
</body>
</html>`;
