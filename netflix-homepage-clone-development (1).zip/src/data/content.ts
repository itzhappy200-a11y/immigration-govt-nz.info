export type Title = {
  id: string;
  name: string;
  imgId: number;
  ext?: "jpeg" | "png";
  year: number;
  maturity: string;
  maturityNote?: string;
  duration: string;
  match: number;
  genres: string[];
  desc: string;
  badge?: "new" | "recent" | "top10";
  badgeText?: string;
  progress?: number;
  episode?: string;
  cast?: string[];
};

export const px = (id: number, w: number, h: number, ext: "jpeg" | "png" = "jpeg") =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.${ext}?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const img = (t: Title, w: number, h: number) => px(t.imgId, w, h, t.ext ?? "jpeg");

const MATURITY = ["TV-MA", "TV-14", "R", "PG-13", "TV-PG", "16+", "18+"];
const NOTES = [
  "violence, language",
  "language, smoking",
  "sexual content, violence",
  "suspense, gore",
  "substances, language",
  "self-harm, violence",
];

const GENRE_POOL = [
  ["Dark", "Suspenseful", "Crime TV Dramas"],
  ["Cerebral", "Sci-Fi", "Mind-Bending"],
  ["Gritty", "Thriller", "Investigation"],
  ["Emotional", "Romantic", "Drama"],
  ["Exciting", "Action", "Adventure"],
  ["Ominous", "Horror", "Supernatural"],
  ["Witty", "Comedy", "Feel-Good"],
  ["Understated", "Docuseries", "Social"],
];

const DESCS = [
  "After a stranger arrives in a quiet coastal town, long-buried secrets resurface — and everyone becomes a suspect.",
  "A brilliant but unraveling detective takes on the one case that could destroy her, and the city she swore to protect.",
  "In a near future where memory can be traded, a black-market broker discovers a recording that rewrites his own past.",
  "Two rival chefs are forced to run the same failing restaurant, and the heat in the kitchen turns into something else.",
  "A family road trip goes catastrophically wrong when the highway they're on stops leading anywhere at all.",
  "Chronicling the rise and spectacular collapse of the most audacious con the art world has ever seen.",
  "She had one job: protect the witness. Nobody told her the witness was the one holding the gun.",
  "Every hundred years the forest takes something. This year, it wants her daughter.",
  "A washed-up stunt driver gets one last shot at glory — if he can survive the people betting against him.",
  "Behind the neon and the noise, a night-shift nurse learns the city keeps its worst secrets after 2 a.m.",
  "An astronaut wakes alone on a derelict station with nine hours of oxygen and a message from herself.",
  "Small town. Big lie. When the river finally dries up, it gives back everything they hid in it.",
];

const CASTS = [
  ["Mara Ellison", "Tobias Kane", "Priya Raghunathan"],
  ["Dev Sharma", "Nina Okonkwo", "Lucas Brandt"],
  ["Ivy Marchetti", "Rowan Vale", "Hiro Tanaka"],
  ["Celeste Dubois", "Andre Whitlock", "Sana Qureshi"],
];

let seed = 7;
const rand = () => {
  seed = (seed * 1103515245 + 12345) % 2147483648;
  return seed / 2147483648;
};

const make = (name: string, imgId: number, i: number, extra: Partial<Title> = {}): Title => {
  const r = rand();
  const isSeries = r > 0.45;
  return {
    id: `${imgId}-${i}-${name.replace(/\s+/g, "").slice(0, 6)}`,
    name,
    imgId,
    year: 2016 + Math.floor(rand() * 10),
    maturity: MATURITY[Math.floor(rand() * MATURITY.length)],
    maturityNote: NOTES[Math.floor(rand() * NOTES.length)],
    duration: isSeries
      ? `${1 + Math.floor(rand() * 5)} Season${Math.floor(rand() * 2) ? "s" : ""}`
      : `${1 + Math.floor(rand() * 2)}h ${10 + Math.floor(rand() * 49)}m`,
    match: 70 + Math.floor(rand() * 30),
    genres: GENRE_POOL[Math.floor(rand() * GENRE_POOL.length)],
    desc: DESCS[Math.floor(rand() * DESCS.length)],
    cast: CASTS[Math.floor(rand() * CASTS.length)],
    ...extra,
  };
};

export const featured: Title = {
  id: "featured-nightfall",
  name: "NIGHTFALL",
  imgId: 0,
  year: 2026,
  maturity: "TV-MA",
  maturityNote: "violence, language, suspense",
  duration: "Limited Series",
  match: 98,
  genres: ["Ominous", "Crime", "Mystery"],
  desc: "When the lights go out across the city for seventy-two hours, a disgraced detective and the daughter of the man she put away must trust each other to stop what's coming with the dawn.",
  cast: ["Mara Ellison", "Tobias Kane", "Priya Raghunathan"],
  badgeText: "New Season",
};

const N = (names: string[], ids: number[], extra: (i: number) => Partial<Title> = () => ({})) =>
  names.map((n, i) => make(n, ids[i % ids.length], i, extra(i)));

const CINEMA = [23384428, 8271461, 23384400, 8263369, 31420645, 7991501, 8263358, 32891033, 34490148, 8273621];
const NEON = [30179307, 8108316, 14044350, 35171253, 8107911, 29326301, 18545010, 8107981, 35171250, 8107907];
const FOREST = [15292814, 18634896, 6227194, 20717826, 10124639, 10486451, 35457879, 10124641, 20717825, 15292814];
const SPACE = [7672873, 7671968, 7661481, 7660828, 7662943, 7662478, 7662473, 8474492, 7661605, 7660832];
const ACTION = [36127686, 10099902, 30925253, 30180763, 30829560, 30180762, 30180757, 18378788, 34920798, 11903164];
const RETRO = [21336125, 3394216, 7299448, 10253241, 38605863, 21336120, 22270204, 8090458, 22270207, 22601538];

export const continueWatching: Title[] = N(
  ["The Silent Hour", "Broken Compass", "Static", "Wolf Season", "The Understudy", "Paper Crowns", "Kill Your Darlings"],
  CINEMA,
  (i) => ({
    progress: [72, 18, 45, 91, 8, 60, 33][i],
    episode: ["S2:E4 The Long Way Down", "S1:E7 Ash", "S3:E1 Signal Lost", "S4:E9 Denning", "S1:E2 Rehearsal", "S2:E6 Gilded", "S1:E5 Ink"][i],
  }),
);

export const trending: Title[] = N(
  ["Neon Requiem", "Downtown Ghosts", "The Amber Room", "Vice Capital", "Glasshouse", "Karma Street", "Rain Machine", "Blue Hour", "The Fixer", "After Midnight"],
  NEON,
  (i) => (i < 4 ? { badge: "recent" as const } : {}),
);

export const top10: Title[] = N(
  ["Hollow Pines", "The Second Wife", "Deadfall", "Ember", "Quiet Part Loud", "Saltwater", "The Cartographer", "Gravehill", "Nine Lives", "Feral"],
  FOREST,
);

export const newReleases: Title[] = N(
  ["Orbital", "Cold Start", "The Mars Letters", "Vacuum", "Signal to Noise", "Terminal Velocity", "Long Way Home", "The Quiet Sea", "Apogee", "Zero Gravity"],
  SPACE,
  (i) => (i % 3 === 0 ? { badge: "new" as const } : {}),
);

export const onlyOnNetflix: Title[] = N(
  ["Dust & Diesel", "Redline County", "The Last Run", "Sandstorm", "Getaway Driver", "Highway 9", "Burn Notice Road", "Chasing Vega", "Outrun", "Detour"],
  ACTION,
);

export const watchItAgain: Title[] = N(
  ["The Paper Anniversary", "Letters from Lisbon", "Smoke & Velvet", "A Year in Between", "The Long Goodbye Club", "Postcards", "Half a Life", "The Gilded Hour", "Rewind", "Second Take"],
  RETRO,
);

export const popular: Title[] = N(
  ["Midnight Diner Society", "The Understory", "Cold Harbour", "Threadbare", "Iron Lantern", "The Bureau of Lost Things", "Nocturne", "Copperline", "Wildfire", "The Inheritance"],
  [...CINEMA.slice(3), ...NEON.slice(0, 3)],
);

export const myList: Title[] = N(
  ["Ash & Ivory", "The Weight of Water", "Northbound", "Ghostwritten", "Salt in the Wound", "The Understudy II", "Bright Lies", "Fault Line"],
  [...FOREST.slice(2), ...RETRO.slice(0, 4)],
);

export type Row = { title: string; items: Title[]; variant?: "top10" | "continue"; };

export const rows: Row[] = [
  { title: "Continue Watching for Alex", items: continueWatching, variant: "continue" },
  { title: "Trending Now", items: trending },
  { title: "Top 10 Movies in the U.S. Today", items: top10, variant: "top10" },
  { title: "New Releases", items: newReleases },
  { title: "Only on Netflix", items: onlyOnNetflix },
  { title: "Watch It Again", items: watchItAgain },
  { title: "Popular on Netflix", items: popular },
  { title: "My List", items: myList },
];

export const profiles = [
  { name: "Alex", color: "from-[#e50914] to-[#8b0000]" },
  { name: "Priya", color: "from-[#2f80ed] to-[#1b3f7a]" },
  { name: "Kids", color: "from-[#f5c518] to-[#c48f00]" },
  { name: "Sam", color: "from-[#3ecf8e] to-[#166c48]" },
];
