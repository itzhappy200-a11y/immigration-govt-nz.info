import { useSyncExternalStore } from "react";

const inList = new Set<string>(["36127686-2-TheLas", "21336125-0-ThePap"]);
const liked = new Set<string>();
const subs = new Set<() => void>();

const emit = () => subs.forEach((f) => f());
const subscribe = (cb: () => void) => {
  subs.add(cb);
  return () => void subs.delete(cb);
};

export function toggleList(id: string) {
  inList.has(id) ? inList.delete(id) : inList.add(id);
  emit();
}

export function toggleLike(id: string) {
  liked.has(id) ? liked.delete(id) : liked.add(id);
  emit();
}

export function useInList(id: string) {
  return useSyncExternalStore(subscribe, () => inList.has(id), () => false);
}

export function useLiked(id: string) {
  return useSyncExternalStore(subscribe, () => liked.has(id), () => false);
}
