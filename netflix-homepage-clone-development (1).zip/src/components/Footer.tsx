const COLS = [
  ["Audio Description", "Investor Relations", "Legal Notices"],
  ["Help Centre", "Jobs", "Cookie Preferences"],
  ["Gift Cards", "Terms of Use", "Corporate Information"],
  ["Media Centre", "Privacy", "Contact Us"],
];

const Social = ({ d, label }: { d: string; label: string }) => (
  <a href="#" aria-label={label} className="text-[#b3b3b3] transition hover:text-white">
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor">
      <path d={d} />
    </svg>
  </a>
);

export default function Footer({ onOpenHtmlModal }: { onOpenHtmlModal?: () => void }) {
  return (
    <footer className="mt-10 px-[4%] pb-14 pt-8 text-[#808080] md:px-[8%]">
      <div className="mb-8 flex items-center justify-between rounded-lg border border-white/15 bg-[#1b1b1b] p-4 text-white sm:p-6">
        <div>
          <h4 className="text-sm font-bold sm:text-base">Need this entire app in a single standalone HTML file?</h4>
          <p className="text-xs text-gray-400">Get the zero-dependency pure HTML5 + Tailwind + Vanilla JS file to run anywhere without Node or React.</p>
        </div>
        <button
          onClick={onOpenHtmlModal}
          className="shrink-0 rounded bg-[#e50914] px-4 py-2 text-xs font-bold text-white shadow transition hover:bg-[#b00710] sm:text-sm"
        >
          📄 View & Download HTML
        </button>
      </div>
      <div className="mb-6 flex gap-6">
        <Social
          label="Facebook"
          d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.52 1.5-3.91 3.77-3.91 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.78-1.63 1.57v1.89h2.78l-.44 2.91h-2.34V22c4.78-.76 8.44-4.92 8.44-9.94Z"
        />
        <Social
          label="Instagram"
          d="M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41-.56-.22-.96-.48-1.38-.9-.42-.42-.68-.82-.9-1.38-.16-.42-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16Zm0 5.68a4.16 4.16 0 1 0 0 8.32 4.16 4.16 0 0 0 0-8.32Zm0 6.86a2.7 2.7 0 1 1 0-5.4 2.7 2.7 0 0 1 0 5.4Zm5.3-7.03a.97.97 0 1 1-1.94 0 .97.97 0 0 1 1.94 0Z"
        />
        <Social
          label="X"
          d="M17.53 3H20l-5.4 6.17L21 21h-5.06l-3.96-5.18L7.44 21H5l5.78-6.6L4 3h5.19l3.58 4.73L17.53 3Zm-.87 16.5h1.37L8.4 4.42H6.93l9.73 15.08Z"
        />
        <Social
          label="YouTube"
          d="M21.58 7.19a2.51 2.51 0 0 0-1.77-1.78C18.25 5 12 5 12 5s-6.25 0-7.81.41A2.51 2.51 0 0 0 2.42 7.2 26.2 26.2 0 0 0 2 12a26.2 26.2 0 0 0 .42 4.81 2.51 2.51 0 0 0 1.77 1.78C5.75 19 12 19 12 19s6.25 0 7.81-.41a2.51 2.51 0 0 0 1.77-1.78A26.2 26.2 0 0 0 22 12a26.2 26.2 0 0 0-.42-4.81ZM10 15.02V8.98L15.2 12 10 15.02Z"
        />
      </div>

      <div className="grid grid-cols-2 gap-y-3 text-[13px] md:grid-cols-4">
        {COLS.map((col, i) => (
          <ul key={i} className="space-y-3">
            {col.map((l) => (
              <li key={l}>
                <a href="#" className="hover:underline">
                  {l}
                </a>
              </li>
            ))}
          </ul>
        ))}
      </div>

      <button className="mt-6 border border-[#808080] px-2 py-1 text-[13px] hover:text-white">
        Service Code
      </button>

      <p className="mt-5 text-[11px]">© 1997–2026 Netflix, Inc.</p>
      <p className="mt-2 max-w-2xl text-[11px] text-[#5c5c5c]">
        This page is a front-end recreation built for demonstration purposes. All titles, artwork and
        descriptions are fictional.
      </p>
    </footer>
  );
}
