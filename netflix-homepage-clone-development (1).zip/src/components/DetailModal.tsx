import { useEffect } from "react";
import { createPortal } from "react-dom";
import { img, popular, trending, type Title } from "../data/content";
import { Check, Close, Muted, Play, Plus, ThumbUp } from "./icons";
import { toggleLike, toggleList, useInList, useLiked } from "./listStore";

export default function DetailModal({ item, onClose }: { item: Title | null; onClose: () => void }) {
  const added = useInList(item?.id ?? "");
  const isLiked = useLiked(item?.id ?? "");

  useEffect(() => {
    if (!item) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [item, onClose]);

  if (!item) return null;

  const similar = [...trending, ...popular].filter((t) => t.id !== item.id).slice(0, 9);

  return createPortal(
    <div className="fixed inset-0 z-[80] overflow-y-auto nfx-scroll bg-black/70" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-fade-up relative mx-auto my-6 w-[92%] max-w-[860px] overflow-hidden rounded-md bg-[#181818] pb-8 shadow-[0_6px_40px_rgba(0,0,0,0.8)] sm:my-[3.5rem]"
      >
        {/* Billboard */}
        <div className="relative aspect-video w-full">
          <img src={img(item, 1200, 675)} alt={item.name} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-[#181818]/10 to-transparent" />
          <div className="absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-[#181818]/70 to-transparent" />

          <button
            onClick={onClose}
            aria-label="Close"
            className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-[#181818] text-white transition hover:bg-[#2a2a2a]"
          >
            <Close className="h-5 w-5" />
          </button>

          <div className="absolute bottom-[7%] left-[4%] right-[4%]">
            <h2 className="text-shadow-nfx mb-4 max-w-[80%] text-[7vw] font-black uppercase leading-[0.95] tracking-tight sm:text-[42px]">
              {item.name}
            </h2>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-2 rounded bg-white px-5 py-1.5 text-[15px] font-semibold text-black transition hover:bg-white/80 sm:px-7 sm:py-2 sm:text-[17px]">
                <Play className="h-5 w-5" />
                Play
              </button>
              <button
                onClick={() => toggleList(item.id)}
                aria-label="Add to My List"
                className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-white/60 bg-[#2a2a2acc] text-white transition hover:border-white"
              >
                {added ? <Check className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
              </button>
              <button
                onClick={() => toggleLike(item.id)}
                aria-label="Rate"
                className={`flex h-10 w-10 items-center justify-center rounded-full border-2 bg-[#2a2a2acc] text-white transition ${
                  isLiked ? "border-white bg-white/20" : "border-white/60 hover:border-white"
                }`}
              >
                <ThumbUp className="h-5 w-5" />
              </button>
              <button
                aria-label="Mute"
                className="ml-auto flex h-10 w-10 items-center justify-center rounded-full border-2 border-white/60 text-white transition hover:border-white"
              >
                <Muted className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="grid grid-cols-1 gap-6 px-[4%] pt-6 md:grid-cols-[1.9fr_1fr]">
          <div>
            <div className="mb-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-[14px]">
              <span className="font-semibold text-[#46d369]">{item.match}% Match</span>
              <span className="text-white/90">{item.year}</span>
              <span className="border border-white/40 px-1.5 text-[12px] text-white/85">{item.maturity}</span>
              <span className="text-white/90">{item.duration}</span>
              <span className="rounded-sm border border-white/40 px-1 text-[10px] leading-4 text-white/70">HD</span>
              <span className="rounded-sm border border-white/40 px-1 text-[10px] leading-4 text-white/70">AD</span>
            </div>
            {item.maturityNote && (
              <div className="mb-4 inline-flex items-center gap-2 text-[13px] text-white/70">
                <span className="border border-white/40 px-1.5 py-[1px] text-[11px]">{item.maturity}</span>
                {item.maturityNote}
              </div>
            )}
            <p className="text-[15px] leading-relaxed text-white/95">{item.desc}</p>
          </div>

          <div className="space-y-2.5 text-[13px] leading-relaxed">
            <p>
              <span className="text-[#777]">Cast: </span>
              {item.cast?.join(", ")}
              <span className="text-[#777]">, more</span>
            </p>
            <p>
              <span className="text-[#777]">Genres: </span>
              {item.genres.join(", ")}
            </p>
            <p>
              <span className="text-[#777]">This show is: </span>
              {item.genres.slice(0, 2).join(", ")}
            </p>
          </div>
        </div>

        {/* More like this */}
        <div className="px-[4%] pt-9">
          <h3 className="mb-4 text-[22px] font-medium">More Like This</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
            {similar.map((s) => (
              <div key={s.id} className="overflow-hidden rounded bg-[#2f2f2f] transition hover:bg-[#3a3a3a]">
                <div className="relative aspect-video">
                  <img src={img(s, 400, 225)} alt={s.name} loading="lazy" className="h-full w-full object-cover" />
                  <span className="absolute right-2 top-2 rounded-sm bg-black/60 px-1 text-[10px] text-white/85">
                    {s.duration}
                  </span>
                </div>
                <div className="p-3">
                  <div className="mb-2 flex items-center gap-2">
                    <span className="border border-white/40 px-1 text-[10px] text-white/80">{s.maturity}</span>
                    <span className="text-[12px] text-white/70">{s.year}</span>
                    <button
                      onClick={() => toggleList(s.id)}
                      className="ml-auto flex h-7 w-7 items-center justify-center rounded-full border-2 border-white/60 hover:border-white"
                      aria-label="Add to My List"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <p className="mb-1 text-[13px] font-semibold text-[#46d369]">{s.match}% Match</p>
                  <p className="line-clamp-3 text-[12.5px] leading-snug text-white/85">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* About */}
        <div className="px-[4%] pt-9">
          <h3 className="mb-4 text-[22px] font-medium">About {item.name}</h3>
          <div className="space-y-2 text-[13px] leading-relaxed">
            <p>
              <span className="text-[#777]">Director: </span>Ana-Sofia Lindqvist
            </p>
            <p>
              <span className="text-[#777]">Cast: </span>
              {item.cast?.join(", ")}, Elias Moreau, Ruth Abara
            </p>
            <p>
              <span className="text-[#777]">Writer: </span>Jonah Reyes
            </p>
            <p>
              <span className="text-[#777]">Genres: </span>
              {item.genres.join(", ")}
            </p>
            <p>
              <span className="text-[#777]">Maturity rating: </span>
              <span className="mx-1 border border-white/40 px-1.5 py-[1px] text-[11px]">{item.maturity}</span>
              {item.maturityNote} — Recommended for ages 18 and up
            </p>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
