import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { img, type Title } from "../data/content";
import { Check, ChevronDown, Play, Plus, ThumbDown, ThumbUp, Muted } from "./icons";
import { toggleLike, toggleList, useInList, useLiked } from "./listStore";

export type PreviewState = { item: Title; rect: DOMRect } | null;

const RoundBtn = ({
  children,
  onClick,
  label,
  primary,
  active,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  label: string;
  primary?: boolean;
  active?: boolean;
  className?: string;
}) => (
  <button
    onClick={onClick}
    aria-label={label}
    title={label}
    className={`group/btn relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 transition ${
      primary
        ? "border-white bg-white text-black hover:bg-white/80"
        : active
          ? "border-white bg-[#2a2a2a] text-white"
          : "border-[#ffffff80] bg-[#2a2a2acc] text-white hover:border-white hover:bg-[#3a3a3a]"
    } ${className}`}
  >
    {children}
  </button>
);

export default function PreviewCard({
  state,
  onClose,
  onOpenDetail,
}: {
  state: PreviewState;
  onClose: () => void;
  onOpenDetail: (t: Title) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  const item = state?.item;
  const added = useInList(item?.id ?? "");
  const isLiked = useLiked(item?.id ?? "");

  useLayoutEffect(() => {
    setShown(false);
    if (!state) return;
    const raf = requestAnimationFrame(() => setShown(true));
    return () => cancelAnimationFrame(raf);
  }, [state]);

  useEffect(() => {
    if (!state) return;
    const close = () => onClose();
    window.addEventListener("scroll", close, { passive: true });
    window.addEventListener("resize", close);
    return () => {
      window.removeEventListener("scroll", close);
      window.removeEventListener("resize", close);
    };
  }, [state, onClose]);

  if (!state || !item) return null;
  const { rect } = state;

  const pw = Math.min(Math.max(rect.width * 1.55, 260), 400);
  const imgH = (pw * 9) / 16;
  let left = rect.left + rect.width / 2 - pw / 2;
  left = Math.min(Math.max(left, 12), window.innerWidth - pw - 12);
  const top = Math.max(rect.top - (imgH - rect.height) / 2 - 26, 78);

  const originX = rect.left + rect.width / 2 - left;
  const originY = rect.top + rect.height / 2 - top;
  const startScale = rect.width / pw;

  return createPortal(
    <div
      ref={ref}
      onMouseLeave={onClose}
      onClick={() => onOpenDetail(item)}
      style={{
        position: "fixed",
        left,
        top,
        width: pw,
        zIndex: 60,
        transformOrigin: `${originX}px ${originY}px`,
        transform: shown ? "scale(1)" : `scale(${startScale})`,
        opacity: shown ? 1 : 0,
        transition: "transform 260ms cubic-bezier(.2,.7,.3,1), opacity 200ms ease",
      }}
      className="cursor-pointer overflow-hidden rounded-md bg-[#181818] shadow-[0_18px_45px_12px_rgba(0,0,0,0.75)]"
    >
      <div className="relative" style={{ height: imgH }}>
        <img src={img(item, 640, 360)} alt={item.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-transparent" />
        <div className="absolute bottom-2 left-3 right-3 flex items-end justify-between">
          <span className="text-shadow-nfx max-w-[75%] truncate text-[15px] font-extrabold uppercase tracking-tight">
            {item.name}
          </span>
          <span className="flex h-7 w-7 items-center justify-center rounded-full border border-white/60 bg-black/40 text-white">
            <Muted className="h-3.5 w-3.5" />
          </span>
        </div>
        {item.progress != null && (
          <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-white/25">
            <div className="h-full bg-[#e50914]" style={{ width: `${item.progress}%` }} />
          </div>
        )}
      </div>

      <div className="p-3.5">
        <div className="flex items-center gap-2">
          <RoundBtn label="Play" primary>
            <Play className="h-4 w-4 translate-x-[1px]" />
          </RoundBtn>
          <RoundBtn
            label={added ? "Remove from My List" : "Add to My List"}
            active={added}
            onClick={(e) => {
              e.stopPropagation();
              toggleList(item.id);
            }}
          >
            {added ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
          </RoundBtn>
          <RoundBtn
            label="I like this"
            active={isLiked}
            onClick={(e) => {
              e.stopPropagation();
              toggleLike(item.id);
            }}
          >
            <ThumbUp className={`h-[17px] w-[17px] ${isLiked ? "text-white" : ""}`} />
          </RoundBtn>
          <RoundBtn label="Not for me" className="hidden sm:flex">
            <ThumbDown className="h-[17px] w-[17px]" />
          </RoundBtn>
          <RoundBtn
            label="More info"
            className="ml-auto"
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetail(item);
            }}
          >
            <ChevronDown className="h-4 w-4" />
          </RoundBtn>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px]">
          <span className="font-semibold text-[#46d369]">{item.match}% Match</span>
          <span className="border border-white/40 px-1 text-[10px] text-white/85">{item.maturity}</span>
          <span className="text-white/85">{item.duration}</span>
          <span className="rounded-sm border border-white/40 px-1 text-[9px] leading-[14px] text-white/70">HD</span>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-x-1.5 text-[12px] text-white/90">
          {item.genres.map((g, i) => (
            <span key={g} className="flex items-center gap-1.5">
              {i > 0 && <span className="text-[6px] text-[#646464]">●</span>}
              {g}
            </span>
          ))}
        </div>
      </div>
    </div>,
    document.body,
  );
}
