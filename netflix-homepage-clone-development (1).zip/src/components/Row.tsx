import { useEffect, useRef, useState } from "react";
import { img, type Row as RowType, type Title } from "../data/content";
import { ChevronLeft, ChevronRight, Play } from "./icons";

type HoverFn = (item: Title, rect: DOMRect) => void;

const canHover = () => typeof window !== "undefined" && window.matchMedia("(hover: hover)").matches;

function Badge({ item }: { item: Title }) {
  if (item.badge === "new")
    return (
      <span className="absolute left-2 top-2 rounded-sm bg-[#e50914] px-1.5 py-[2px] text-[9px] font-bold uppercase tracking-wide shadow">
        New
      </span>
    );
  if (item.badge === "recent")
    return (
      <span className="absolute left-2 top-2 rounded-sm bg-black/70 px-1.5 py-[2px] text-[9px] font-bold uppercase tracking-wide text-[#e50914] shadow">
        Recently Added
      </span>
    );
  return null;
}

function Card({
  item,
  onHover,
  variant,
  rank,
  onOpen,
}: {
  item: Title;
  onHover: HoverFn;
  variant?: RowType["variant"];
  rank?: number;
  onOpen: (t: Title) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const timer = useRef<number | undefined>(undefined);

  const enter = () => {
    if (!canHover()) return;
    timer.current = window.setTimeout(() => {
      if (ref.current) onHover(item, ref.current.getBoundingClientRect());
    }, 400);
  };
  const leave = () => window.clearTimeout(timer.current);
  useEffect(() => () => window.clearTimeout(timer.current), []);

  if (variant === "top10") {
    return (
      <div
        ref={ref}
        onMouseEnter={enter}
        onMouseLeave={leave}
        onClick={() => onOpen(item)}
        className="group relative flex w-[58vw] flex-none cursor-pointer items-end sm:w-[42vw] md:w-[31vw] lg:w-[24.5vw] xl:w-[20.5vw]"
      >
        <span className="top10-number w-[46%] select-none pl-[2%] text-[15vw] sm:text-[11vw] md:text-[8.4vw] lg:text-[6.6vw] xl:text-[5.6vw]">
          {rank}
        </span>
        <div className="relative -ml-[3%] aspect-[2/3] w-[57%] overflow-hidden rounded-[3px]">
          <img
            src={img(item, 420, 630)}
            alt={item.name}
            loading="lazy"
            className="h-full w-full object-cover transition duration-300 group-hover:brightness-110"
          />
        </div>
      </div>
    );
  }

  return (
    <div
      ref={ref}
      onMouseEnter={enter}
      onMouseLeave={leave}
      onClick={() => onOpen(item)}
      className="group relative w-[42vw] flex-none cursor-pointer sm:w-[30vw] md:w-[22.6vw] lg:w-[18.1vw] xl:w-[15.1vw]"
    >
      <div className="relative aspect-video overflow-hidden rounded-[4px] bg-[#222]">
        <img
          src={img(item, 480, 270)}
          alt={item.name}
          loading="lazy"
          className="h-full w-full object-cover"
        />
        <Badge item={item} />
        {variant === "continue" && (
          <>
            <div className="absolute inset-0 flex items-center justify-center bg-black/25 opacity-0 transition group-hover:opacity-100">
              <span className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white/80 bg-black/40">
                <Play className="h-5 w-5 translate-x-[1px] text-white" />
              </span>
            </div>
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-2 pb-1.5 pt-6">
              <p className="truncate text-[11px] font-medium text-white/90">{item.episode}</p>
            </div>
          </>
        )}
      </div>
      {variant === "continue" && (
        <div className="mt-[6px] h-[3px] w-full bg-[#4d4d4d]">
          <div className="h-full bg-[#e50914]" style={{ width: `${item.progress ?? 0}%` }} />
        </div>
      )}
    </div>
  );
}

export default function Row({
  row,
  onHover,
  onOpen,
}: {
  row: RowType;
  onHover: HoverFn;
  onOpen: (t: Title) => void;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  const [page, setPage] = useState(0);
  const [pages, setPages] = useState(1);
  const [moved, setMoved] = useState(false);

  const measure = () => {
    const el = scroller.current;
    if (!el) return;
    const p = Math.max(1, Math.ceil(el.scrollWidth / el.clientWidth));
    setPages(p);
    setPage(Math.round(el.scrollLeft / el.clientWidth));
    setMoved(el.scrollLeft > 8);
  };

  useEffect(() => {
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const slide = (dir: 1 | -1) => {
    const el = scroller.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.92, behavior: "smooth" });
  };

  return (
    <section className="group/row relative mb-[3vw] mt-1">
      <div className="mb-2 flex items-center px-[4%]">
        <h2 className="group/title flex cursor-pointer items-center text-[1.05rem] font-medium text-[#e5e5e5] transition hover:text-white md:text-[clamp(15px,1.4vw,26px)]">
          {row.title}
          <span className="ml-2 flex translate-x-[-8px] items-center gap-1 whitespace-nowrap text-[clamp(11px,0.85vw,15px)] font-semibold text-[#54b9c5] opacity-0 transition-all duration-300 group-hover/row:translate-x-0 group-hover/row:opacity-100 max-md:hidden">
            Explore All
            <ChevronRight className="h-3 w-3" />
          </span>
        </h2>
        {pages > 1 && (
          <div className="ml-auto hidden items-center gap-[2px] opacity-0 transition group-hover/row:opacity-100 md:flex">
            {Array.from({ length: pages }).map((_, i) => (
              <span
                key={i}
                className={`h-[2px] w-3 ${i === page ? "bg-[#aaa]" : "bg-[#4d4d4d]"}`}
              />
            ))}
          </div>
        )}
      </div>

      <div className="relative">
        {moved && (
          <button
            onClick={() => slide(-1)}
            aria-label="Previous"
            className="absolute bottom-0 left-0 top-0 z-20 flex w-[4%] items-center justify-center bg-black/40 text-white opacity-0 transition hover:bg-black/70 group-hover/row:opacity-100 max-md:hidden"
          >
            <ChevronLeft className="h-[2vw] w-[2vw] transition-transform hover:scale-125" />
          </button>
        )}

        <div
          ref={scroller}
          onScroll={measure}
          className="no-scrollbar flex gap-[0.4vw] overflow-x-auto scroll-smooth px-[4%] pb-1"
        >
          {row.items.map((item, i) => (
            <Card
              key={item.id}
              item={item}
              rank={i + 1}
              variant={row.variant}
              onHover={onHover}
              onOpen={onOpen}
            />
          ))}
        </div>

        <button
          onClick={() => slide(1)}
          aria-label="Next"
          className="absolute bottom-0 right-0 top-0 z-20 flex w-[4%] items-center justify-center bg-black/40 text-white opacity-0 transition hover:bg-black/70 group-hover/row:opacity-100 max-md:hidden"
        >
          <ChevronRight className="h-[2vw] w-[2vw] transition-transform hover:scale-125" />
        </button>
      </div>
    </section>
  );
}
