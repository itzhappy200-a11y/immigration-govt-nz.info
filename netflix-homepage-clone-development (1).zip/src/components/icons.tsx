type P = { className?: string };

export const NetflixLogo = ({ className }: P) => (
  <svg viewBox="0 0 1024 276.742" className={className} fill="#e50914" aria-label="Netflix">
    <path d="M140.803 258.904c-15.404 2.705-31.079 3.516-47.294 5.676l-49.458-144.856v151.073c-15.404 1.621-29.457 3.783-44.051 5.945v-276.742h41.08l56.212 157.021v-157.021h43.511v258.904zm85.131-157.558c16.757 0 42.431-.811 57.835-.811v43.24c-19.189 0-41.619 0-57.835.811v64.322c25.405-1.621 50.809-3.785 76.482-4.596v41.617l-119.724 9.461v-255.39h119.724v43.241h-76.482v58.105zm237.284-58.104h-44.862v198.908c-14.594 0-29.188 0-43.239.539v-199.447h-44.862v-43.242h132.965l-.002 43.242zm70.266 55.132h59.187v43.24h-59.187v98.104h-42.433v-239.718h120.808v43.241h-78.375v55.133zm148.641 103.507c24.594.539 49.456 2.434 73.51 3.783v42.701c-38.646-2.434-77.293-4.863-116.75-5.676v-242.689h43.24v201.881zm109.994 49.457c13.783.812 28.377 1.623 42.43 3.242v-254.58h-42.43v251.338zm231.881-251.338l-54.863 131.615 54.863 145.127c-16.217-2.162-32.432-5.135-48.648-7.838l-31.078-79.994-31.617 73.51c-15.678-2.705-30.812-3.516-46.484-5.678l55.672-126.75-50.269-129.992h46.482l28.377 72.699 30.27-72.699h47.295z" />
  </svg>
);

export const NIcon = ({ className }: P) => (
  <svg viewBox="0 0 300 512" className={className} fill="none">
    <defs>
      <linearGradient id="nfx" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#e50914" />
        <stop offset="1" stopColor="#8b0000" />
      </linearGradient>
    </defs>
    <path fill="url(#nfx)" d="M0 0h84l132 374V0h84v512h-84L84 138v374H0z" />
  </svg>
);

export const Play = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M5 3.868v16.264a1 1 0 0 0 1.53.848l12.79-8.132a1 1 0 0 0 0-1.696L6.53 3.02A1 1 0 0 0 5 3.868Z" />
  </svg>
);

export const Info = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="9.5" />
    <path d="M12 10.5v6" strokeLinecap="round" />
    <circle cx="12" cy="7.4" r="1.15" fill="currentColor" stroke="none" />
  </svg>
);

export const Plus = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const Check = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m4.5 12.5 5 5 10-11" />
  </svg>
);

export const ThumbUp = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round">
    <path d="M7 10.5 11 2c1.6 0 2.6 1 2.6 2.5V9h4.6c1.4 0 2.4 1.3 2.1 2.6l-1.5 6.6A2.6 2.6 0 0 1 16.3 20H7z" />
    <rect x="2.6" y="10" width="4.4" height="10" rx="1" />
  </svg>
);

export const ThumbDown = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round">
    <path d="M17 13.5 13 22c-1.6 0-2.6-1-2.6-2.5V15H5.8c-1.4 0-2.4-1.3-2.1-2.6l1.5-6.6A2.6 2.6 0 0 1 7.7 4H17z" />
    <rect x="17" y="4" width="4.4" height="10" rx="1" />
  </svg>
);

export const ChevronDown = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m5 9 7 7 7-7" />
  </svg>
);

export const ChevronRight = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d="m9 5 7 7-7 7" />
  </svg>
);

export const ChevronLeft = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d="m15 5-7 7 7 7" />
  </svg>
);

export const Search = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
    <circle cx="10.8" cy="10.8" r="6.8" />
    <path d="m15.8 15.8 4.2 4.2" />
  </svg>
);

export const Bell = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M12 2a6.5 6.5 0 0 0-6.5 6.5v3.2L3.3 16.2a.8.8 0 0 0 .7 1.2h16a.8.8 0 0 0 .7-1.2l-2.2-4.5V8.5A6.5 6.5 0 0 0 12 2Z" />
    <path d="M9.6 18.6a2.5 2.5 0 0 0 4.8 0z" />
  </svg>
);

export const Close = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M6 6 18 18M18 6 6 18" />
  </svg>
);

export const Volume = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 9.5h3.2L12 5.5v13L7.2 14.5H4z" />
    <path d="M16 9a4.5 4.5 0 0 1 0 6" />
    <path d="M18.6 6.4a8.2 8.2 0 0 1 0 11.2" />
  </svg>
);

export const Muted = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 9.5h3.2L12 5.5v13L7.2 14.5H4z" />
    <path d="m16.5 9.5 5 5M21.5 9.5l-5 5" />
  </svg>
);

export const Grid = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <rect x="3" y="3" width="7" height="7" rx="1" />
    <rect x="14" y="3" width="7" height="7" rx="1" />
    <rect x="3" y="14" width="7" height="7" rx="1" />
    <rect x="14" y="14" width="7" height="7" rx="1" />
  </svg>
);

export const Avatar = ({ className, from = "#e50914", to = "#8b0000" }: P & { from?: string; to?: string }) => (
  <svg viewBox="0 0 64 64" className={className}>
    <defs>
      <linearGradient id={`av-${from.replace("#", "")}`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={from} />
        <stop offset="1" stopColor={to} />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="4" fill={`url(#av-${from.replace("#", "")})`} />
    <circle cx="23" cy="26" r="4.2" fill="#fff" />
    <circle cx="41" cy="26" r="4.2" fill="#fff" />
    <path d="M20 40c3.5 4.6 8 6.8 12 6.8S40.5 44.6 44 40" stroke="#fff" strokeWidth="3.4" fill="none" strokeLinecap="round" />
  </svg>
);
