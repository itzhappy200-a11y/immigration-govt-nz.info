import { useState } from "react";
import { featured } from "../data/content";
import { Info, Muted, NIcon, Play, Volume } from "./icons";

export default function Hero({ onMoreInfo }: { onMoreInfo: () => void }) {
  const [muted, setMuted] = useState(true);

  return (
    <section className="relative w-full">
      <div className="relative h-[62vh] min-h-[440px] w-full sm:h-[80vh] lg:h-[56.25vw] lg:max-h-[860px]">
        <img
          src="/images/hero.jpg"
          alt={featured.name}
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src =
              "https://images.pexels.com/photos/30179307/pexels-photo-30179307.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1080";
          }}
          className="absolute inset-0 h-full w-full object-cover object-[60%_center]"
        />
        {/* Netflix vignettes */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/45 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-[14.7vw] min-h-[100px] bg-gradient-to-t from-[#141414] via-[#141414]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20" />

        {/* Copy */}
        <div className="absolute inset-x-0 bottom-[16%] px-[4%] sm:bottom-[22%] lg:bottom-[26%]">
          <div className="hero-in max-w-[95%] sm:max-w-[560px] lg:max-w-[640px]">
            <div className="mb-3 flex items-center gap-2">
              <NIcon className="h-[26px] w-[16px]" />
              <span className="text-[13px] font-semibold tracking-[0.28em] text-[#d2d2d2] sm:text-[15px]">
                SERIES
              </span>
            </div>

            <h1 className="text-shadow-nfx text-[13vw] font-black leading-[0.88] tracking-[-0.03em] text-white sm:text-[64px] lg:text-[84px]">
              {featured.name}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2 text-[13px] text-white/90 sm:text-[15px]">
              <span className="rounded bg-[#e50914] px-2 py-[3px] text-[11px] font-bold uppercase tracking-wide">
                {featured.badgeText}
              </span>
              <span className="font-semibold text-[#46d369]">{featured.match}% Match</span>
              <span>{featured.year}</span>
              <span className="border border-white/40 px-1.5 text-[12px]">{featured.maturity}</span>
              <span>{featured.duration}</span>
              <span className="hidden rounded border border-white/40 px-1.5 text-[11px] sm:inline">HD</span>
            </div>

            <p className="text-shadow-nfx mt-4 line-clamp-3 max-w-[560px] text-[14px] leading-snug text-white sm:text-[17px] sm:leading-normal lg:text-[19px]">
              {featured.desc}
            </p>

            <div className="mt-6 flex items-center gap-3">
              <button className="flex items-center gap-2 rounded bg-white px-5 py-2 text-[15px] font-semibold text-black transition hover:bg-white/80 sm:gap-3 sm:px-7 sm:py-2.5 sm:text-[19px]">
                <Play className="h-5 w-5 sm:h-6 sm:w-6" />
                Play
              </button>
              <button
                onClick={onMoreInfo}
                className="flex items-center gap-2 rounded bg-[#6d6d6eb3] px-5 py-2 text-[15px] font-semibold text-white transition hover:bg-[#6d6d6e66] sm:gap-3 sm:px-7 sm:py-2.5 sm:text-[19px]"
              >
                <Info className="h-5 w-5 sm:h-6 sm:w-6" />
                More Info
              </button>
            </div>
          </div>
        </div>

        {/* Mute + maturity */}
        <div className="absolute bottom-[32%] right-0 hidden items-center sm:flex lg:bottom-[35%]">
          <button
            onClick={() => setMuted((m) => !m)}
            className="mr-[4%] flex h-10 w-10 items-center justify-center rounded-full border-2 border-white/60 text-white/90 transition hover:border-white hover:bg-white/10"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <Muted className="h-5 w-5" /> : <Volume className="h-5 w-5" />}
          </button>
          <div className="flex h-9 items-center border-l-[3px] border-white bg-[#33333366] pl-3 pr-[4%] text-[15px] text-white backdrop-blur-[1px]">
            <span className="mr-2 font-medium">{featured.maturity}</span>
            <span className="hidden text-[13px] text-white/85 md:inline">{featured.maturityNote}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
