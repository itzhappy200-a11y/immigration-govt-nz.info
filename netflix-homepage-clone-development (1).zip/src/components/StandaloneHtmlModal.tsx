import { useState } from "react";
import { createPortal } from "react-dom";
import { STANDALONE_HTML } from "../data/standaloneHtml";
import { Check, Close } from "./icons";

export default function StandaloneHtmlModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<"code" | "preview">("code");

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(STANDALONE_HTML);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleDownload = () => {
    const blob = new Blob([STANDALONE_HTML], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "netflix.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return createPortal(
    <div
      onClick={onClose}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 p-3 backdrop-blur-sm sm:p-6"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-[90vh] w-full max-w-[1100px] flex-col overflow-hidden rounded-lg border border-white/20 bg-[#141414] shadow-[0_20px_60px_rgba(0,0,0,0.95)]"
      >
        {/* Top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-[#1b1b1b] p-4 px-6">
          <div className="flex items-center gap-3">
            <span className="rounded bg-[#e50914] px-2 py-0.5 text-xs font-bold tracking-wider text-white">
              HTML FILE
            </span>
            <h2 className="text-lg font-bold text-white sm:text-xl">
              Single-File Vanilla HTML Implementation
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex rounded-md border border-white/20 bg-black/50 p-0.5 text-xs">
              <button
                onClick={() => setViewMode("code")}
                className={`rounded px-3 py-1.5 font-medium transition ${
                  viewMode === "code" ? "bg-[#e50914] text-white" : "text-gray-300 hover:text-white"
                }`}
              >
                Code View
              </button>
              <button
                onClick={() => setViewMode("preview")}
                className={`rounded px-3 py-1.5 font-medium transition ${
                  viewMode === "preview" ? "bg-[#e50914] text-white" : "text-gray-300 hover:text-white"
                }`}
              >
                Live Preview
              </button>
            </div>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 rounded bg-white px-4 py-1.5 text-xs font-bold text-black transition hover:bg-gray-200"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 text-emerald-600" /> Copied to Clipboard!
                </>
              ) : (
                "Copy HTML Code"
              )}
            </button>

            <button
              onClick={handleDownload}
              className="rounded bg-[#46d369] px-4 py-1.5 text-xs font-bold text-black shadow transition hover:bg-[#3ebe5d]"
            >
              Download netflix.html
            </button>

            <a
              href="/netflix-standalone.html"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden rounded border border-white/30 bg-[#2a2a2a] px-3 py-1.5 text-xs font-semibold text-white transition hover:border-white sm:inline-block"
            >
              Open in New Tab ↗
            </a>

            <button
              onClick={onClose}
              className="ml-2 flex h-8 w-8 items-center justify-center rounded-full bg-white/10 text-gray-300 transition hover:bg-white/20 hover:text-white"
              aria-label="Close"
            >
              <Close className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Info notice */}
        <div className="border-b border-white/10 bg-[#202020] px-6 py-2.5 text-xs text-gray-300 flex items-center justify-between">
          <p>
            ✨ <strong>Ready to run anywhere:</strong> Contains 100% self-contained HTML5, Tailwind CDN styling, and vanilla JavaScript (no React or CLI build tools required).
          </p>
          <span className="text-gray-400 font-mono text-[11px] max-sm:hidden">~14 KB standalone</span>
        </div>

        {/* Main Body */}
        <div className="relative flex-1 overflow-hidden bg-[#0d0d0d]">
          {viewMode === "code" ? (
            <pre className="nfx-scroll h-full w-full overflow-auto p-5 font-mono text-xs leading-relaxed text-emerald-400 selection:bg-emerald-900 selection:text-white sm:text-sm">
              <code>{STANDALONE_HTML}</code>
            </pre>
          ) : (
            <iframe
              src="/netflix-standalone.html"
              title="Netflix Standalone HTML Preview"
              className="h-full w-full border-0 bg-white"
            />
          )}
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between border-t border-white/10 bg-[#181818] px-6 py-3 text-xs text-gray-400">
          <span>Save as <strong>index.html</strong> on your Desktop and double-click to run!</span>
          <button
            onClick={onClose}
            className="rounded bg-white/10 px-4 py-1.5 text-white hover:bg-white/20"
          >
            Close Window
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
