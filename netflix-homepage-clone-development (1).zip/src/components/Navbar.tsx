import { useEffect, useRef, useState } from "react";
import { Avatar, Bell, ChevronDown, Close, NetflixLogo, Search } from "./icons";
import { profiles } from "../data/content";

const LINKS = ["Home", "TV Shows", "Movies", "New & Popular", "My List", "Browse by Languages"];

const NOTIFS = [
  { title: "Nightfall", sub: "New Season Now Available", img: 30179307, when: "2h ago" },
  { title: "Hollow Pines", sub: "Now on Netflix", img: 15292814, when: "1d ago" },
  { title: "Orbital", sub: "Recently added to Netflix", img: 7672873, when: "3d ago" },
];

export default function Navbar({ onOpenHtmlModal }: { onOpenHtmlModal: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [openMenu, setOpenMenu] = useState<"none" | "bell" | "profile" | "browse">("none");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (searchOpen) inputRef.current?.focus();
  }, [searchOpen]);

  useEffect(() => {
    const close = () => setOpenMenu("none");
    window.addEventListener("scroll", close, { passive: true });
    return () => window.removeEventListener("scroll", close);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-[#141414]" : "bg-gradient-to-b from-black/80 via-black/40 to-transparent"
      }`}
    >
      <div className="flex h-[68px] items-center px-[4%] text-[14px]">
        {/* Logo */}
        <a href="#" className="mr-1 shrink-0 md:mr-6" aria-label="Netflix home">
          <NetflixLogo className="h-[25px] w-[92px]" />
        </a>

        {/* Desktop links */}
        <nav className="hidden items-center gap-5 lg:flex">
          {LINKS.map((l, i) => (
            <a
              key={l}
              href="#"
              className={`whitespace-nowrap transition-colors hover:text-[#b3b3b3] ${
                i === 0 ? "font-medium text-white" : "text-[#e5e5e5]"
              }`}
            >
              {l}
            </a>
          ))}
          <button
            onClick={onOpenHtmlModal}
            className="flex items-center gap-1.5 rounded-sm bg-[#e50914] px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-white shadow transition hover:bg-[#b00710]"
          >
            ⚡ Single-File HTML
          </button>
        </nav>

        {/* Mobile Browse dropdown */}
        <div className="relative lg:hidden">
          <button
            onClick={() => setOpenMenu(openMenu === "browse" ? "none" : "browse")}
            className="ml-3 flex items-center gap-1.5 text-[13px] text-white"
          >
            Browse
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          {openMenu === "browse" && (
            <div className="animate-fade absolute left-0 top-[42px] w-[220px] border-t-2 border-white bg-black/90 py-2 text-center">
              {LINKS.map((l) => (
                <a key={l} href="#" className="block px-4 py-2.5 text-[13px] text-[#e5e5e5] hover:underline">
                  {l}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Right side */}
          <button
            onClick={onOpenHtmlModal}
            className="flex items-center gap-1 rounded bg-[#e50914] px-2 py-[5px] text-[11px] font-bold text-white shadow transition hover:bg-[#b00710] lg:hidden"
          >
            ⚡ HTML Code
          </button>
        <div className="ml-auto flex items-center gap-4 sm:gap-5">
          {/* Search */}
          <div className="flex items-center">
            {searchOpen ? (
              <div className="flex items-center gap-2 border border-white/60 bg-black/80 px-2.5 py-[6px]">
                <Search className="h-[18px] w-[18px] text-white" />
                <input
                  ref={inputRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Titles, people, genres"
                  className="w-[150px] bg-transparent text-[13px] text-white outline-none placeholder:text-[#8c8c8c] sm:w-[210px]"
                />
                <button onClick={() => { setSearchOpen(false); setQuery(""); }} aria-label="Close search">
                  <Close className="h-4 w-4 text-white/80 hover:text-white" />
                </button>
              </div>
            ) : (
              <button onClick={() => setSearchOpen(true)} aria-label="Search">
                <Search className="h-[22px] w-[22px] text-white transition-transform hover:scale-110" />
              </button>
            )}
          </div>

          <a href="#" className="hidden text-[14px] text-white hover:text-[#b3b3b3] xl:block">
            Children
          </a>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setOpenMenu(openMenu === "bell" ? "none" : "bell")}
              className="relative block"
              aria-label="Notifications"
            >
              <Bell className="h-[22px] w-[22px] text-white" />
              <span className="absolute -right-1 -top-0.5 flex h-[15px] min-w-[15px] items-center justify-center rounded-full bg-[#e50914] px-1 text-[9px] font-bold leading-none">
                3
              </span>
            </button>
            {openMenu === "bell" && (
              <div className="animate-fade absolute right-[-60px] top-[38px] w-[330px] border-t-2 border-white bg-black/90 py-2 shadow-2xl sm:right-0 sm:w-[380px]">
                {NOTIFS.map((n) => (
                  <a key={n.title} href="#" className="flex items-center gap-3 px-4 py-3 hover:bg-white/10">
                    <img
                      src={`https://images.pexels.com/photos/${n.img}/pexels-photo-${n.img}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=180&h=100`}
                      alt=""
                      className="h-[52px] w-[92px] shrink-0 rounded-sm object-cover"
                    />
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-medium text-white">{n.sub}</p>
                      <p className="truncate text-[13px] text-[#b3b3b3]">{n.title}</p>
                      <p className="mt-0.5 text-[11px] text-[#8c8c8c]">{n.when}</p>
                    </div>
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Profile */}
          <div
            className="relative"
            onMouseEnter={() => setOpenMenu("profile")}
            onMouseLeave={() => setOpenMenu("none")}
          >
            <button className="flex items-center gap-2" aria-label="Profile">
              <Avatar className="h-8 w-8 rounded" from="#e50914" to="#8b0000" />
              <ChevronDown
                className={`hidden h-3.5 w-3.5 text-white transition-transform duration-300 sm:block ${
                  openMenu === "profile" ? "rotate-180" : ""
                }`}
              />
            </button>
            {openMenu === "profile" && (
              <div className="animate-fade absolute right-0 top-[30px] w-[200px] pt-[18px]">
                <div className="border-t-2 border-white bg-black/90 py-2">
                  {profiles.slice(1).map((p, i) => (
                    <a key={p.name} href="#" className="flex items-center gap-3 px-3 py-2 text-[13px] hover:underline">
                      <Avatar
                        className="h-8 w-8 rounded"
                        from={["#2f80ed", "#f5c518", "#3ecf8e"][i]}
                        to={["#1b3f7a", "#c48f00", "#166c48"][i]}
                      />
                      {p.name}
                    </a>
                  ))}
                  <div className="mt-2 border-t border-white/20 pt-2">
                    {["Manage Profiles", "Transfer Profile", "Account", "Help Centre"].map((x) => (
                      <a key={x} href="#" className="block px-3 py-1.5 text-[13px] hover:underline">
                        {x}
                      </a>
                    ))}
                    <a href="#" className="mt-2 block border-t border-white/20 px-3 pt-3 text-center text-[13px] hover:underline">
                      Sign out of Netflix
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
