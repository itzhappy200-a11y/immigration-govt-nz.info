import { useCallback, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Row from "./components/Row";
import PreviewCard, { type PreviewState } from "./components/PreviewCard";
import DetailModal from "./components/DetailModal";
import Footer from "./components/Footer";
import StandaloneHtmlModal from "./components/StandaloneHtmlModal";
import { featured, rows, type Title } from "./data/content";

export default function App() {
  const [preview, setPreview] = useState<PreviewState>(null);
  const [detail, setDetail] = useState<Title | null>(null);
  const [htmlModalOpen, setHtmlModalOpen] = useState(false);

  const handleHover = useCallback((item: Title, rect: DOMRect) => {
    setPreview({ item, rect });
  }, []);

  const openDetail = useCallback((t: Title) => {
    setPreview(null);
    setDetail(t);
  }, []);

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      <Navbar onOpenHtmlModal={() => setHtmlModalOpen(true)} />

      <main>
        <Hero onMoreInfo={() => setDetail(featured)} />

        <div className="relative z-10 -mt-[6vw] pb-6 md:-mt-[9vw]">
          {rows.map((row) => (
            <Row key={row.title} row={row} onHover={handleHover} onOpen={openDetail} />
          ))}
        </div>
      </main>

      <Footer onOpenHtmlModal={() => setHtmlModalOpen(true)} />

      <PreviewCard state={preview} onClose={() => setPreview(null)} onOpenDetail={openDetail} />
      <DetailModal item={detail} onClose={() => setDetail(null)} />
      <StandaloneHtmlModal isOpen={htmlModalOpen} onClose={() => setHtmlModalOpen(false)} />
    </div>
  );
}
